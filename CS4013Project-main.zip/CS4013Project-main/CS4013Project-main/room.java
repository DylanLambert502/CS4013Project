public class room {
    /**
     * Index of arrays represent the following values
     * 0-Number of rooms
     * 1-Occupancy-min
     * 2-Occupancy-max
     * (3-9 Inclusive) Rates for Monday through to Sunday
     */
    //5 Star Rooms
    int[] DD = {35,1,2,75,75,75,80,90,90,75};
    int[] DT = {35,1,2,75,75,75,80,90,90,75};
    int[] DS = {10,1,2,70,70,70,75,80,80,65};
    int[] DF = {10,1,3,80,80,80,80,100,100,80};
    //4 Star Rooms
    int[] ED = {40,1,2,70,70,70,70,80,85,85};
    int[] ET = {32,1,2,70,70,70,70,80,85,85};
    int[] ES = {12,1,1,65,65,65,65,70,75,80};
    //3 Start Rooms
    int[] CD = {45,1,2,65,65,70,70,75,80,65};
    int[] CT = {45,1,2,65,65,70,70,80,85,65};
    int[] CS = {10,1,1,50,50,50,60,75,75,50};



}


