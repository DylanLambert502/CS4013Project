import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;


public class writeReservations {
    public static void main(String[] args) throws FileNotFoundException {
        // somehow grab the information from reservations
        //                        int reservationNumber,
        //                        String reservationName,
        //                        char reservationType,
        //                        LocalDate checkInDate, LocalDate checkOutDate,
        //                        int numberOfRooms,
        //                        String[][] rooms,
        //                        double cost



        reservations one = new reservations(1, "Jim",'S',
                2021-01-13, 2021-01-20, 1, DD , 200);
        reservations two = new reservations(2, "Joe",'S',
                2021-01-20, 2021-01-25, 1 , 'DD' );

        ArrayList<reservations> reservationList = new ArrayList<>();

        File csvFile = new File("reservations.csv");
        PrintWriter out = new PrintWriter(csvFile);

        reservationList.add(one);
        reservationList.add(two);

        for (reservations reservations : reservationList){
            out.printf("%s, %d\n", reservations.getReservationNumber(), reservations.getReservationName(),
                    reservations.getNumberOfRooms(), reservations.getReservationType(),reservations.getRoomTypes(),
                    reservations.getCheckInDate(), reservations.getCheckOutDate());
        }
        out.close();
    }

}

/*
    Couple of things:
    1) Need to set up the adding the reservations in properly instead of creating it in here like with "one: and "two"
    2) need to search the l4hotels csv file to make sure that there is space in the room
    3) figure out format of   LocalDate checkInDate, LocalDate checkOutDate, to input into the arraylist
    4) ^ same with "rooms"
 */