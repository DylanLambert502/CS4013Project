# CS4013Project
Group project for CS4013 OOP


11/11/2021 TO DO:
* Implement days of the week calculator to get what days the reservation is for 
* Finish totalCost method in reservations class (Will require above to be done first)
* Implement a class to write the reservations to csv file 
